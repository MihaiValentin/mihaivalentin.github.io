<?php
/*
Plugin Name: WP User theme switch - Different theme for a particular user
Plugin URI: http://www.mihaivalentin.com/different-wordpress-theme-depending-of-the-current-user/
Description: Useful for developing new versions of the site. The admin user will se the theme he works on, and the normal users will continue to see the normal theme.
Version: 1.0
Author: Mihai Valentin
Author URI: http://www.mihaivalentin.com/
*/

$mv_theme_switch = array(
	'user' => '<<insert user for which you want to show a different theme here>>',
	'theme' => '<<insert the "different" theme here'
);

require_once (ABSPATH . WPINC . '/pluggable.php');
global $current_user;
get_currentuserinfo();

function mv_theme_switch_callback($t) {
	global $mv_theme_switch;
	return $mv_theme_switch['theme'];
}

if ($current_user->user_login == $mv_theme_switch['user']) {
	add_filter('stylesheet', 'mv_theme_switch_callback');
	add_filter('template', 'mv_theme_switch_callback');	
}

?>